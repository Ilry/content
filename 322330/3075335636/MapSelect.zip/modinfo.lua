name = "刷地图！"
description = "本MOD所需生成时间可能长达数小时！！！\n通过判断关键资源点的距离和重置世界来获取一张长期档好图！\n（当前版本仅判断猪王，月台，龙蝇，蜂后距离及是否带有海象平原。）\n可以自由调整世界生成设置，如环形，分支，地图大小等（但可能会影响生成速度）\n强烈建议关闭所有mod，移除洞穴，仅开启本mod进行生成！\n根据测试，带有mod地形的mod可同时开启，但不能保证兼容性（目前测试永不妥协地形生成正常）\n生成完毕后关闭本mod再加入其它mod，添加洞穴。\n长时间重复的生成世界是正常情况，建议睡前开启本mod，睡醒看是否生成完毕。\n想调整关键资源距离可以点开modinfo文件，修改资源点距离选项中的数值。该值越大，关键资源距离越远，生成时间越短；反之关键资源越近，生成时间越长。\n注意：该值改得过低时可能导致永远无法生成出符合要求的地图！（建议生成一晚上没生成出来就改大一些）此时需要强制关闭游戏并修改该值！\n测试基于小世界，更大的世界建议适当将值调大！"
author = "好黑好黑的大黑"
version = "1.2.0" -- 整体思路.内容更新.修bug

api_version = 10

dst_compatible = true
restart_required = false
all_clients_require_mod = true
icon = "modicon.tex"
icon_atlas = "modicon.xml"

configuration_options = {

    { name = "Title", label = "地图类型", options = { { description = "", data = "0" }, }, default = "0", }, --|>
    -----------------------------------------------------------------------------------------------------------------------/
    {
        name = "map_type",
        label = "地图类型",
        hover = "你想要什么样的地图？",
        options = {
            { description = "资源优先", data = "0", hover = "根据关键资源点之间的距离生成地图。" },
            { description = "绿洲优先", data = "1", hover = "根据关键资源点离绿洲的距离生成地图。（试运行，生成时间可能较长，资源距离可能较远）" },
            --{ description = "速通优先", data = "2", hover = "根据棋子数量及盐矿位置生成地图。" },
        },
        default = "0",
    },
    {
        name = "distance",
        label = "资源点距离",
        hover = "根据你的地图大小选择合适的资源距离（只对资源优先地图类型生效）",
        options = {
            { description = "很近", data = 30000, hover = "只建议在小地图使用，时间长" },
            { description = "近", data = 50000, hover = "建议在小地图使用" },
            { description = "普通", data = 60000, hover = "建议在中地图使用" },
            { description = "较远", data = 70000, hover = "建议在大地图使用" },
            --{ description = "速通优先", data = "2", hover = "根据棋子数量及盐矿位置生成地图。" },
        },
        default = 50000,
    },
    emptyspaceoption,

    ------------------------------------------------------------------------------------------------------------------------------\
    --{ name = "Title", label = "需求资源", options = { { description = "", data = "0" }, }, default = "0", }, --|>
    ------------------------------------------------------------------------------------------------------------------------------/
    --{ name = "beequeen",
    --  label = "蜂后",
    --  hover = "蜂后是否是你需要的资源？",
    --  options = {
    --      { description = "是", data = "1", hover = "近一点吧！" },
    --      { description = "否", data = "0", hover = "在哪都无所谓。" }, },
    --  default = "1", },
    --
    --{ name = "pigking",
    --  label = "猪王",
    --  hover = "猪王是否是你需要的资源？",
    --  options = {
    --      { description = "是", data = "1", hover = "近一点吧！" },
    --      { description = "否", data = "0", hover = "在哪都无所谓。" }, },
    --  default = "1", },
    --{ name = "moonbase",
    --  label = "月台",
    --  hover = "月台是否是你需要的资源？",
    --  options = {
    --      { description = "是", data = "1", hover = "近一点吧！" },
    --      { description = "否", data = "0", hover = "在哪都无所谓。" }, },
    --  default = "1", },
    --{ name = "dragonfly",
    --  label = "龙蝇",
    --  hover = "龙蝇是否是你需要的资源？",
    --  options = {
    --      { description = "是", data = "1", hover = "近一点吧！" },
    --      { description = "否", data = "0", hover = "在哪都无所谓。" }, },
    --  default = "1", },
}
